from flask import Blueprint, render_template, request, redirect, url_for
from .forms import EventForm
from .models import Event
from . import db

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def index():
    return render_template('index.html')

@main_bp.route('/createevent', methods=['GET', 'POST'])
def create_event():
    form = EventForm()
    if form.validate_on_submit():
        new_event = Event(
            event_name=form.event_name.data,
            description=form.description.data,
            event_type=form.event_type.data,
            checkin_date=form.checkin_date.data,
            checkout_date=form.checkout_date.data,
            checkin_time=form.checkin_time.data,
            checkout_time=form.checkout_time.data,
            status=form.status.data
        )
        db.session.add(new_event)
        db.session.commit()
        return redirect(url_for('main.view_event'))  # or wherever you want
    return render_template('createevent.html', form=form)



@main_bp.route('/user')
def user():
    return render_template('user.html')


@main_bp.route('/eventhistory')
def event_history():
    return render_template('eventhistory.html')


@main_bp.route('/viewevent')
def view_event():
    return render_template('viewevent.html')
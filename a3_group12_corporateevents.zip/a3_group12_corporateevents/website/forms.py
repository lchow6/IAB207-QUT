from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, TextAreaField, SubmitField
from wtforms.validators import InputRequired, Length, Email, EqualTo
from wtforms import DateTimeField, SelectField
from wtforms.validators import DataRequired

from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, TextAreaField, SubmitField, DateTimeField, SelectField
from wtforms.validators import InputRequired, Length, Email, EqualTo, DataRequired

# Login Form
class LoginForm(FlaskForm):
    user_name = StringField("User Name", validators=[InputRequired('Enter user name')])
    password = PasswordField("Password", validators=[InputRequired('Enter user password')])
    submit = SubmitField("Login")

# Register Form
class RegisterForm(FlaskForm):
    user_name = StringField("User Name", validators=[InputRequired()])
    email = StringField("Email Address", validators=[Email("Please enter a valid email")])
    password = PasswordField("Password", validators=[InputRequired(),
                    EqualTo('confirm', message="Passwords should match")])
    confirm = PasswordField("Confirm Password")
    submit = SubmitField("Register")

# Event Form
class EventForm(FlaskForm):
    event_name = StringField('Event Name', validators=[DataRequired()])
    description = TextAreaField('Description', validators=[DataRequired()])
    event_type = StringField('Event Type', validators=[DataRequired()])
    checkin_date = DateTimeField('Check-in Date', format='%Y-%m-%d %H:%M', validators=[DataRequired()])
    checkout_date = DateTimeField('Check-out Date', format='%Y-%m-%d %H:%M', validators=[DataRequired()])
    checkin_time = DateTimeField('Check-in Time', format='%Y-%m-%d %H:%M', validators=[DataRequired()])
    checkout_time = DateTimeField('Check-out Time', format='%Y-%m-%d %H:%M', validators=[DataRequired()])
    status = SelectField('Status', choices=[
        ('Open', 'Open'),
        ('Inactive', 'Inactive'),
        ('Sold Out', 'Sold Out'),
        ('Cancelled', 'Cancelled')
    ], validators=[DataRequired()])
    submit = SubmitField('Create Event')
